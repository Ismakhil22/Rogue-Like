import theGame

def heal(creature, value): #heal lié à une potion, va aussi rajouter des mp au héros
    """Heal the creature"""
    if creature.hp + value <= creature.hpMax:
        creature.mp+=3
        a = value - (creature.hpMax - creature.hp)
        if a <= 0:
            creature.hp += value
            theGame.theGame().addMessage(f"The hero heals {value} hp")
        else:
            creature.hp += value - a
            theGame.theGame().addMessage(f"The hero heals {value - a} hp")
        return True
    theGame.theGame().addMessage("The hero has already max hp")
    return False
def soin(creature,value): #soin lié au sort
    if creature.hp + value <= creature.hpMax:
        a = value - (creature.hpMax - creature.hp)
        if a <= 0:
            creature.hp += value
            theGame.theGame().addMessage(f"The hero heals {value} hp")
        else:
            creature.hp += value - a
            theGame.theGame().addMessage(f"The hero heals {value - a} hp")
        return True
    theGame.theGame().addMessage("The hero has already max hp")
    return False
def teleport(creature, unique): #téléporte la créature à une coordonnée aléatoire
    """Teleport the creature"""
    r = theGame.theGame()._floor.randRoom()
    c = r.randCoord()
    while theGame.theGame()._floor.get(c) != theGame.theGame()._floor.ground:
        r = theGame.theGame()._floor.randRoom()
        c = r.randCoord()
    theGame.theGame()._floor.rm(theGame.theGame()._floor.pos(creature))
    theGame.theGame()._floor.put(c, creature)
    return unique

def vision(creature):
    #permet à la créature de voir toute la carte sans fumée
    theGame.theGame()._floor.fullVision()
    return True

def food(creature):
    #remet la satiete de la créature "à 0"
    creature.satiete=20.25
    return True

def throw(power, loss):
    """Throw an object"""
    pass

def Poison(c1, creature):           #c1 est self et creature la creature associée
    creature.poison = 5
    return "Poison"

def useAmulette(item):
    theGame.theGame()._hero.amuletteAction(item)        #permet d'appliquer l'amulette

def invisibilite(creature): #applique l'effet invisible au hero pendant 5 tours
    creature.__setattr__("invisible",5)
    creature.__setattr__("abbrv","9") 

def superforce(creature): #rajoute de la strength au héros
    creature.__setattr__("strength",creature.strength*1.5)
