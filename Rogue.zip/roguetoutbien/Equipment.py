from Element import Element
import theGame

class Equipment(Element):
    """A piece of equipment"""

    def __init__(self, name, abbrv="", usage=None, durab = 1):
        Element.__init__(self, name, abbrv)
        self.usage = usage
        self.durab = durab              #attribut déterminant la durabilité d'un équipement

    def meet(self, hero):
        """Makes the hero meet an element. The hero takes the element."""
        if hero == theGame.theGame()._hero:
            if len(hero.INVENTORY)<10: #limite le nombre d'éléments dans l'inventaire à 10 (le gold étant compté différement)
                hero.take(self)
                theGame.theGame().addMessage("You pick up a " + self.name)
            else:
                theGame.theGame().addMessage("The inventory is now full !")
        return True

    def use(self, creature):
        """Uses the piece of equipment. Has effect on the hero according usage.
            Return True if the object is consumed."""
        if self.usage == "arme":
            creature.useWeapon(self)
            theGame.theGame().addMessage("The " + creature.name + " equips the " + self.name)

        elif self.usage == "armor":
            creature.useArmor(self)
            theGame.theGame().addMessage("The " + creature.name + " equips the " + self.name)
            
                     
        elif self.usage is None:
            theGame.theGame().addMessage("The " + self.name + " is not usable")
            return False
        
        else:
            theGame.theGame().addMessage("The " + creature.name + " uses the " + self.name)
            return self.usage(self, creature)
