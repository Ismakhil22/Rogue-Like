from Equipment import Equipment
from Arme import Arme
from Armure import Armure
from Creature import Creature
from Coord import Coord
from Hero import Hero
from Map import Map
from Stairs import Stairs
from Shop import Shop
from handler import *
import theGame
from time import time
import Affichage
import keyboard
import time
from Tresor import Tresor
from Sort import Sort



import random, copy

class Game(object):
    """ Class representing game state """

    """ available equipments """
    equipments = {0: [Equipment("potion", "!", usage=lambda self, hero: heal(hero, 3)), \
                      Arme("sword", strength = 5, durab = 1), \
                      Equipment("vision potion", "8", usage=lambda self, hero: vision(hero)), \
                      Equipment("Meat","M",usage=lambda self, hero: food(hero) ), \
                      Armure(name = "Bronze", abbrv =  "A", durability = 3), \
                     # Arme("/ stick", strength = 1), \
                      Equipment("gold", "o")], \
                  1: [Equipment("teleport potion", "!", usage=lambda self, hero: teleport(hero, True))], \
                  2: [Equipment("bow", usage=lambda self, hero: throw(1, True)), Arme("sword", strength = 5)], \
                  3: [Equipment("portoloin", "w", usage=lambda self, hero: teleport(hero, False)), \
                      Equipment("AmuletteV","V",usage=lambda self, hero: useAmulette(hero),durab=5), \
                      Equipment("AmuletteF","F",usage=lambda self, hero: useAmulette(hero), durab=5), \
                      Equipment("AmuletteX","X",usage=lambda self, hero: useAmulette(hero), durab=5)], \
                  4: [Armure(name='Or',abbrv="3", durability = 5), \
                      Arme(name="Golden Sword",abbrv="5",strength=7,durab=3)],
                  7: [Armure(name="Fer",abbrv="1",durability=7),
                      Arme(name="Iron Sword",abbrv="6",strength=7,durab=5)],
                  10: [Armure(name="Diamant",abbrv="0",durability=10),
                       Arme(name="Diamond Sword",abbrv="2",strength=10,durab=7)]
                  }
    """ available monsters """
    monsters = {0: [Creature("Goblin", 4, XP = 2), Creature("Bat", 2, abbrv = "W", XP = 1)],
                1: [Creature("Ork", 6, strength=2, XP = 2), Creature(name = "Spider", abbrv = "S", hp=4, strength=0.5, XP = 2, usage=Poison),  Creature("Blob", 10, XP = 3)],
                2: [Creature("Cheetah",3, abbrv = "C", strength=1.5,speed=1, XP = 3)], \
                4: [Creature("Sorcier", abbrv= "µ",hp=10,strength=3,XP=4,usage=lambda self, hero: teleport(hero, True))],
                5: [Creature("Dragon", 20, strength=3, XP = 5)], \
                7: [Creature("Dragon", 20, strength=5, XP = 7)], \
                8: [Creature(name = "Vampire", abbrv = "£", hp=20, strength=5, XP = 10, usage=Poison)],
                10: [Creature("Demon", abbrv="%",hp=40, strength=8, XP=20)],
                15: [Creature("FINAL BOSS",abbrv="§",hp=40,strength=3,speed=3,XP=100)]
                }
    """ available spells """
    sorts = [Sort("Invisibilite", mp=5, usage=lambda self,hero:invisibilite(hero)),
             Sort("Téléportation", mp=5, usage=lambda self, hero: teleport(hero, True)),
             Sort("Soin", mp=7, usage=lambda self, hero: soin(hero,5)),
             Sort("Superforce", mp=10, usage=lambda self,Hero: superforce(Hero)),
             Sort("Vision", mp=2, usage=lambda self, hero: vision(hero)),
             Sort("Invincibilité", mp=10, usage=lambda self, Hero: Hero.__setattr__("invincible",5))]

    """ available actions """
    _actions = {'z': lambda h: theGame.theGame()._floor.move(h, Coord(0, -1)), \
                'q': lambda h: theGame.theGame()._floor.move(h, Coord(-1, 0)), \
                's': lambda h: theGame.theGame()._floor.move(h, Coord(0, 1)), \
                'd': lambda h: theGame.theGame()._floor.move(h, Coord(1, 0)), \
                'a': lambda h: theGame.theGame()._floor.move(h, Coord(-1, -1)), \
                'e': lambda h: theGame.theGame()._floor.move(h, Coord(1, -1)), \
                'w': lambda h: theGame.theGame()._floor.move(h, Coord(-1, 1)), \
                'x': lambda h: theGame.theGame()._floor.move(h, Coord(1, 1)), \
                'i': lambda h: theGame.theGame().addMessage(h.fullDescription()), \
                'k': lambda h: h.__setattr__('hp', 0), \
                'u': lambda h: h.use(theGame.theGame().selectInventory(h.INVENTORY)), \
                ' ': lambda h: None, \
                'r': lambda h: h.reject(theGame.theGame().selectInventory(h.INVENTORY)), \
                'h': lambda hero: theGame.theGame().addMessage("Actions disponibles : " + str(list(Game._actions.keys()))), \
                'b': lambda hero: theGame.theGame().addMessage("I am " + hero.name), \
                'm':lambda Hero:Hero.use(theGame.theGame().selectSort(Game.sorts)), \
                }

    def __init__(self, level=1, hero=None):
        self._level = level
        self._messages = []
        if hero == None:
            hero = Hero( inventory = [Armure(name = "Bronze", abbrv =  "A", durability = 3)] )
        self._hero = hero
        self._floor = None
        self.floor_level=1

    def buildFloor(self):
        """Creates a map for the current floor."""
        self._floor = Map(hero=self._hero)
        self._floor.put(self._floor._rooms[-1].center(), Stairs())
        self._level += 1

    def buildFloorShop(self, shop):
        """Creates a map for the current floor."""
        self._floor = Map(hero=self._hero)
        self._floor.put(self._floor._rooms[-1].center(), Stairs())
        self._floor.put(self._floor._rooms[0].randEmptyCoord(self._floor), shop)
        self._level += 1
    
    def buildFloorTrap(self):
        self._floor = Map(hero=self._hero)
        self._floor.put(self._floor._rooms[-1].center(), Stairs())
        k=self._floor.randRoom()
        for i in range(random.randint(3,5)):
            self._floor.put(k.randEmptyCoord(self._floor),Creature(name="Trap",hp=1,abbrv=".",strength=2))
        self._level += 1
    
    def buildFloorTresor(self):
        self._floor=Map(hero=self._hero)
        self._floor.put(self._floor._rooms[-1].center(),Stairs())
        if self._floor.i%4!=0:
            self.monstreAleatoire(self._floor._elem).__setattr__("cle",True)
            self._floor.put(self._floor._rooms[-2].center(),Tresor())
        self._level+=1
        

    def addMessage(self, msg):
        """Adds a message in the message list."""
        self._messages.append(msg)

    def readMessages(self):
        """Returns the message list and clears it."""
        s = ''
        for m in self._messages:
            s += m + '. '
        self._messages.clear()
        return s

    def randElement(self, collect):
        """Returns a clone of random element from a collection using exponential random law."""
        x = random.expovariate(1 / self._level)
        l=[]
        for k in collect.keys():
            if k <= x: 
                l = collect[k]
        return copy.copy(random.choice(l))

    def randEquipment(self):
        """Returns a random equipment."""
        return self.randElement(Game.equipments)

    def randMonster(self):
        """Returns a random monster."""
        return self.randElement(Game.monsters)
    def monstreAleatoire(self,collection): #renvoie un monstre aléatoire parmis ceux présent sur l'étage
        l=[]
        for i in collection.keys():
            if isinstance(i,Creature) and not isinstance(i,Hero):
                l.append(i)
        if l!=[]:
            return random.choice(l)
        
            

    def selectInventory(self, l): 
        
        Affichage.use(l)
        time.sleep(0.2)
        c = keyboard.read_key()
        if c.isdigit() and 0<=int(c)<=len(l)-1:
            return l[int(c)]
        return None
    def selectSort(self,l): #Fonction qui sélectionne un sort dans ceux existants
       
        Affichage.use(l)
        time.sleep(0.2)
        c = keyboard.read_key()
        if c.isdigit() and 0<=int(c)<=len(l)-1:
            return l[int(c)]
        return None
    
    def levels(self, n):
        a = self._hero.lvl
        if self._hero.XP >= a*n:
            a+=1
            self.addMessage(f"Your Hero levels up to {self._hero.lvl+1} !!")
            self._hero.__setattr__('hpMax', self._hero.hpMax+self._hero.lvl)
            self._hero.__setattr__('hp', self._hero.hpMax)
            
        self._hero.lvl = a
        self._hero.__setattr__("strength", 1 + a)         #Cette fonction a été disposée ici à cause des importations circulaires
        if not self._hero.arme == None:
            self._hero.strength += self._hero.arme.strength
            

    def play(self):
        """Main game loop"""
        Affichage.add(Game.equipments)
        Affichage.add(Game.monsters)
        Affichage.resize()
        Affichage.startGame()
        time.sleep(0.2)
        c = keyboard.read_key()
        self.buildFloor()
        c = "s"
        while self._hero.hp > 0:
            self.levels(self._hero.lvl*3)
            self._floor.addVisible()
            Affichage.affichage(self._floor._mat, self._floor.visible, c, self._hero, self._level, self.readMessages(), self.floor_level)
            time.sleep(0.2)
            c = keyboard.read_key()
            
            if c in Game._actions:
                Game._actions[c](self._hero)
                self._hero.Satiété()
                if self._hero.poison > 0:                           #Si le héros est empoisonné, il perd des hp
                    self._hero.hp -= 0.5
                    self._hero.poison -= 1
                    
                if self._hero.amulette!=[]:   #à chaque itération (action du joueur), la fonction de l'effect de l'amulette est appelée
                    for i in self._hero.amulette: #à condition que l'inventaire d'amulettes ne soit pas vide.
                        if i.durab>0:
                            self._hero.amuletteAction(i)
                            i.durab -= 1
                        else:
                            self._hero.amulette.remove(i)
                if self._hero.invisible>0: #va tester si le héros est invisible
                    self._hero.invisible-=1
                else:
                    self._hero.__setattr__("abbrv","@") #va mettre l'abbrv à @ pour que le héros soit encore reconnaissable des monstres
                            
            self._floor.moveAllMonsters()
        Affichage.endGame()
        time.sleep(0.2)
        c = keyboard.read_key()
        #print("--- Game Over ---")
