from Equipment import Equipment

class Armure(Equipment):
    def __init__(self, name, abbrv="A", durability = 0):
        Equipment.__init__(self, name, abbrv)
        self.durability = durability                        #Détermine la résistance de l'armure
        self.usage = "armor"
        
    def description(self):
        return f"<{self.name}/{self.durability}>"
