
import theGame

theGame.theGame().play()