from Creature import Creature
from Armure import Armure
from Equipment import Equipment
from Arme import Arme
from handler import *
from Sort import Sort


class Hero(Creature):
    
    def __init__(self, name="Hero", hp=10, abbrv="@", strength=2, inventory=None, armor=None, satiete = 20,LVL = 1, XP = 0, hpMax = 10, arme = None, amulette=[],mp=10):       ##armor est un équipement de type armure, cet équipement aura une valeur durabilité, et à durabilité 0 il se détruit      
        Creature.__init__(self, name, hp, abbrv, strength)
        if hp > hpMax:
            hp = hpMax
        self.hpMax = hpMax                  #les hpMax du héros
        self.hp = hp
        self.XP = XP                                #l'expérience du héros
        self.satiete = satiete
        self.INVENTORY = inventory
        if self.INVENTORY == None:
            self.INVENTORY = []
        self.armor = armor
        self.lvl = LVL
        self.gold = 0
        self.arme = arme
        self.amulette = amulette
        self.mp=mp                            #attribut lié aux points de magie

    def description(self):
        return Creature.description(self)+str(self.INVENTORY)+" Sat: "+str(self.satiete) + f" gold : {self.gold}"

    def take(self, elem): 
        if not isinstance(elem, Equipment):
            raise TypeError("Must be an Equipment type")
        if isinstance(elem, Armure):
            self.armor = elem
        elif elem.name == "gold":
            self.gold += 1
        elif elem.name == "AmuletteV" or elem.name == "AmuletteF" or elem.name == "AmuletteX":    #évalue si l'élément à prendre est une amulette et non un objet quelconque 
            self.amulette.append(elem)
        else:
            self.INVENTORY.append(elem)
        


    def fullDescription(self):
        desc = ""
        liste = [i for i in self.__dict__.keys()]
        index = 0
        for i in self.__dict__.values():
            desc += "> " + liste[index] + " : " + str(i)
            index += 1
            if index < len(liste):
                desc+= "\n"
        return desc

            

    def use(self, item):
        if item == None:
            return None
        
        if not isinstance(item, Equipment) and not isinstance(item,Sort):
            raise TypeError("Ce n'est ni un équipement ni un sort")
        if isinstance(item,Sort): 
            if self.mp>=item.mp:
                item.use(self) #permet d'utiliser le sort
                self.mp-=item.mp #décremente les mp du héros des mp nécessaires à l'éxécution du sort
            else:
                return None
        else:
            if not item in self.INVENTORY:
                raise ValueError("L'item n'est pas dans l'inventaire")
            

            if item.use(self):
                item.durab -= 1 #permet de décrémenter la durabilité de l'équipment
                #print(item.durab)
                if item.durab == 0:
                    self.INVENTORY.remove(item)

    def useWeapon(self, item):                                  #permet d'équiper une arme
        if not self.arme == None:
            self.INVENTORY.append(self.arme)
            self.arme = None
            self.strength = 1 + self.lvl                            #réinitialise la strength du héros
        self.arme = item
        self.INVENTORY.remove(item)

    def useArmor(self, item):                                   #permet d'équiper une armure
        if not self.armor == None:
            self.INVENTORY.append(self.armor)
            self.armor = None
        self.armor = item
        self.INVENTORY.remove(item)

    def reject(self, item):                         #permet de rejeter un objet de l'inventaire
        if not item == None:
            self.INVENTORY.remove(item)

    def amuletteAction(self, item):
        #Cette fonction code l'effet des amulettes sur le héros quand une action est effectuée.
        if item.name == "AmuletteV":
            """Amulette de vie fait son effet"""
            heal(self, 0.5)
        elif item.name == "AmuletteF":
            """Amulette de force fait son effet"""
            self.strength += 0.25
        elif item.name == "AmuletteX":
            """Amulette d'XP fait son effet"""
            self.XP += 0.5
        

    def Satiété(self):                              #permet d'appliquer la satiété au héros
        impact_satiété = -0.25
        if self.satiete==0:
            self.hp += impact_satiété
        else:
            self.satiete += impact_satiété
