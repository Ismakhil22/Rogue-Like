from Equipment import Equipment

class Arme(Equipment):
    """L'arme de notre héros"""

    def __init__(self, name, abbrv = "", usage = "arme", durab = 5, strength = 3):
        Equipment.__init__(self, name, abbrv, usage, durab)
        self.strength = strength


