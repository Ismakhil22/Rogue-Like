import theGame
class Sort():
    def __init__(self,name,usage=None,mp=0):
        self.name=name
        self.usage=usage
        self.mp=mp
    def use(self, creature):
        """Uses the piece of equipment. Has effect on the hero according usage.
            Return True if the object is consumed."""
        if creature.mp>=self.mp:
            if self.usage is None:
                theGame.theGame().addMessage("The " + self.name + " is not usable")
                return False
            else:
                theGame.theGame().addMessage("The " + creature.name + " uses the spell " + self.name)
                return self.usage(self, creature)
        else:
            theGame.theGame().addMessage("Not enough MP !")
