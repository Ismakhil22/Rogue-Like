from Element import Element
import theGame

class Shop(Element):
    """ Shop where the Hero can buy items """

    def __init__(self, shop = [], price = 1):
        super().__init__("shop", '$')
        self.shop = shop
        self.price = price

    def meet(self, hero):
        """Hero can buy something"""
        theGame.theGame().addMessage(f"The price of the Shop is {self.price} golds")
        i = theGame.theGame().selectInventory(self.shop)
        if i == None:
            return None
        if hero.gold >= self.price :
            if i.name == "AmuletteV" or i.name == "AmuletteF" or i.name == "AmuletteX":
                hero.amulette.append(i)
            else:
                hero.INVENTORY.append(i)
            hero.gold = self.price
            theGame.theGame().addMessage("The " + hero.name + " buys " + i.name)

        else:
            theGame.theGame().addMessage("The " + hero.name + " has not enough money (needs at least " + str(self.price) + "golds...)")
