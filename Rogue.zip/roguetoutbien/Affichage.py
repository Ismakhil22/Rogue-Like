import pygame
from pygame.locals import *
from Coord import Coord
from win32api import GetSystemMetrics

#Prendre les mesures de l'écran
width = GetSystemMetrics (0)
height = GetSystemMetrics (1)

#On initialise l'affichage
pygame.init()
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption('Roguelike')
font = pygame.font.SysFont('impact.ttf', 64)

#Prépare la taille de chaque case du jeu dans l'affichage en fonction de la taille de l'écran
width=screen.get_size()[0]
height=screen.get_size()[1]
size=(0.62*width)//20
if size>height//21:
    size=height//21

#On ajoute le fond
background=pygame.image.load("./assets/background.png").convert()
background=pygame.transform.scale(background, screen.get_size())
screen.blit(background, (0,0))


#import image
sol = pygame.image.load("./assets/ground.png")
fumee = pygame.image.load("./assets/fumee.png")
empty=pygame.image.load("./assets/empty.png")
player_front=pygame.image.load("./assets/characters/player_front.png")
player_back=pygame.image.load("./assets/characters/player_back.png")
player_right=pygame.image.load("./assets/characters/player_right.png")
player_left=pygame.image.load("./assets/characters/player_left.png")
monster=pygame.image.load("./assets/monsters/default.png")
stairs=pygame.image.load("./assets/stairs.png")
unkown=pygame.image.load("./assets/unknown.jpg").convert()
shop=pygame.image.load("./assets/shop.png")
end=pygame.image.load("./assets/end.png")
tresor=pygame.image.load("./assets/tresor.png")
start=pygame.image.load("./assets/start.png")


#player invisible
player_front_i=pygame.image.load("./assets/characters/player_front_i.png")
player_back_i=pygame.image.load("./assets/characters/player_back_i.png")
player_right_i=pygame.image.load("./assets/characters/player_right_i.png")
player_left_i=pygame.image.load("./assets/characters/player_left_i.png")


#dictionnaire abbrv->image
liens={
    '.':sol,
    ' ':empty,
    '#':fumee,
    '@s' :player_front,
    '@z': player_back,
    '@q': player_left,
    '@d': player_right,
    'E': stairs,
    '$': shop,
    'T':tresor,
    '9s' :player_front_i,
    '9z': player_back_i,
    '9q': player_left_i,
    '9d': player_right_i,
    'unknown': unkown
}

#ajoute pour chaque éléments / monstres
def add(collection):
    for elements in collection:
        for i in collection[elements]:
            if "potion" in i.name.lower():
                name="potion"
            else:
                name=i.name.lower().replace(" ", "_")
            liens[i.abbrv]=pygame.image.load("./assets/"+name+".png")


#resize
def resize():
    for i in liens:
        liens[i]=pygame.transform.scale(liens[i], (size, size))

#Affiche chaque infos du joueur sur l'écran
def infos(hero, level, floor_level):
    hp = font.render(str(hero.hp), True, (255, 0, 0))
    food=font.render(str(hero.satiete), True, (255, 0, 0))
    gold=font.render(str(hero.gold), True, (255, 0, 0))
    level=font.render(str(hero.lvl), True, (255, 0, 0))
    floor=font.render(str(floor_level), True, (255, 0, 0))

    screen.blit(hp, (int(0.72*width), int(0.125*height)))
    screen.blit(food, (int(0.75*width), int(0.19*height)))
    screen.blit(gold, (int(0.74*width), int(0.263*height)))
    screen.blit(floor, (int(0.76*width), int(0.407*height)))
    screen.blit(level, (int(0.757*width), int(0.333*height)))
    h=width
    for i in hero.INVENTORY:
        a=liens[i.abbrv]
        screen.blit(pygame.transform.scale(a, (40, 40)), (int(0.661*h), int(0.541*height)))
        h+=45

#Affiche pour l'utilisation d'un equipement (select)
def use(l):
    font2 = pygame.font.SysFont('impact.ttf', 40)
    texte=[]
    h=height
    choose = font2.render("Choose Item > ", True, (255, 0, 0))
    screen.blit(choose, (int(0.635*width), int(0.7*height)))
    for e in l:
        texte.append(str(l.index(e))+" : "+e.name)
    for line in texte:
        choose = font2.render(line, True, (255, 0, 0))
        screen.blit(choose, (int(0.75*width), int(0.7*h)))
        h+=45
    pygame.display.update()

#Affiche les messages du jeu
def readMessage(message):
    font2 = pygame.font.SysFont('impact.ttf', 30)
    #print(message)
    texte = font2.render(message, True, (255, 0, 0))
    screen.blit(texte, (int(0.034*width), 0.01*height))

#Ecran de début
def startGame():
    startScreen=pygame.transform.scale(start, screen.get_size())
    screen.blit(startScreen, (0,0))
    pygame.display.update()

#Ecran de fin
def endGame():
    endScreen=pygame.transform.scale(end, screen.get_size())
    screen.blit(endScreen, (0,0))
    pygame.display.update()
    


#Affiche la carte du jeu
def affichage(mat, visible, c, hero, level, message, floor_level):
    screen.blit(background, (0,0))
    for y in range(len(mat)):
        for x in range(len(mat[0])):
            if mat[x][y]!=' ':
                screen.blit(liens['.'], (y*size, x*size))
            if Coord(y, x) not in visible and mat[x][y]!=' ':
                screen.blit(liens['#'], (y*size, x*size))
            else:
                if mat[x][y] not in ['.', ' ']:
                    if mat[x][y].abbrv == '@':
                        if c in ['z', 'q', 's', 'd']:
                            position=mat[x][y].abbrv+c
                            screen.blit(liens[position], (y*size, x*size))
                        else:
                            screen.blit(liens['@s'], (y*size, x*size))
                    elif mat[x][y].abbrv == '9':
                        if c in ['z', 'q', 's', 'd']:
                            position=mat[x][y].abbrv+c
                            screen.blit(liens[position], (y*size, x*size))
                        else:
                            screen.blit(liens['9s'], (y*size, x*size))
                    elif mat[x][y].abbrv in liens.keys():
                        screen.blit(liens[mat[x][y].abbrv], (y*size, x*size))
                    else:
                        screen.blit(liens['unknown'], (y*size, x*size))
    infos(hero, level, floor_level)
    readMessage(message)
    pygame.display.update()
