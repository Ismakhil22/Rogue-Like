from Element import Element
import theGame
import random
import copy
class Tresor(Element):
    def __init__(self,contenu=[]):
        Element.__init__(self,"Tresor")
        self.contenu=contenu
        self.niveau=theGame.theGame()._level*2
    def randElementTresor(self, collect): #va choisir un élément au hasard dans un dictionnaire
        """Returns a clone of random element from a collection using exponential random law."""
        x = random.expovariate(1 / self.niveau)
        l=[]
        for k in collect.keys():
            if k <= x: 
                l = collect[k]
        return copy.copy(random.choice(l))
    def meet(self,hero): #code l'interaction trésor/héros
        theGame.theGame().addMessage("Do you have the key ?")
        if hero.cle and isinstance(hero,Hero) and len(hero.INVENTORY)<10:
            k=self.randElementTresor(theGame.Game.equipments)
            theGame.theGame().addMessage(f"You pick up a {k.name}")
            hero.take(k)
            hero.__setattr__("cle",False)
        else:
            theGame.theGame().addMessage("You don't have the key !")
            
