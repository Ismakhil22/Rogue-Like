from Element import Element
import theGame
from handler import *

class Creature(Element):
    """A creature that occupies the dungeon.
        Is an Element. Has hit points and strength."""

    def __init__(self, name, hp, abbrv="", strength=1, XP = 0, speed = 0,usage=None, poison=0,invisible=0,invincible=0,cle=False):
        Element.__init__(self, name, abbrv)
        self.hp = hp
        self.strength = strength
        self.XP = XP
        self.speed = speed
        self.usage=usage                                    #attribut permettant à la créature d'avoir une capacité (poison par exemple)
        self.poison=poison                                  #attribut permettant de savoir si la créature est empoisonnée
        self.invisible=invisible                            #attribut permettant de savoir si la créature est invisible
        self.invincible=invincible                          #attribut permettant de savoir si la créature est empoisonnée
        self.cle=cle
        
        


    def description(self):
        """Description of the creature"""
        return Element.description(self) + "(" + str(self.hp) + ")"

    def meet(self, other):
        """The creature is encountered by an other creature.
            The other one hits the creature. Return True if the creature is dead."""
        if self.invincible==0: #ne fait des dégâts à la creature self qui si elle n'est pas invincible
            if self.name == theGame.theGame()._hero.name and self.armor != None:                  #vérifie si la créature possède une armure
                self.armor.durability -= other.strength
                if self.armor.durability <= 0:
                    self.armor = None
            else:
                self.hp -= other.strength
            if other.name == theGame.theGame()._hero.name :
                other.__setattr__("abbrv","@") #modifie l'abbrv du héros pour que si il soit invisible, il redevienne visible (lié au test dans moveAllMonsters)
                if other.arme != None:
                    other.arme.durab -= 1               #à chaque fois que le héros attaque avec une arme, elle perd de sa durabilité
                    if other.arme.durab <= 0:
                        other.arme = None
            if other.usage != None:
                other.use(self)                            #applique l'effet de la créature sur le héros
                
            theGame.theGame()._messages.append(f"The {other.name} hits the {self.miniDesc()} with {other.strength} damage")
            if self.hp <= 0:
                other.XP += self.XP
                if self.cle:
                    theGame.theGame()._messages.append("You found the key !")
                    other.__setattr__("cle",True)
                return True
            return False
        self.invincible-=1 if self.invincible>0 else None
        
    
    def use(self, creature):
        #Méthode permettant d'appliquer les "pouvoirs" de la créature sur l'autre créature
        name = "   "
        if self.usage == Poison:
            name = "Poison"
        if not self.usage is None:
            theGame.theGame().addMessage("The " + self.name + " applies " + name)
            return self.usage(self, creature)

    def miniDesc(self):
        return Element.description(self)+f"({self.hp}) / ({self.XP})"
