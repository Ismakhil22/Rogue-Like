from Element import Element
import theGame
from Shop import Shop
from Arme import Arme
import random

class Stairs(Element):
    """ Strairs that goes down one floor. """

    def __init__(self):
        super().__init__("Shop", 'E')

    def meet(self, hero): #gestion des salles, permet de coder des salles spéciales aléatoirement
        """Goes down"""
        j=random.randint(1,5)
        if j==1 or j==2:
            theGame.theGame().buildFloor()
        elif j==3:
            boutique = []
            for i in range(3):
                boutique.append(theGame.theGame().randEquipment())
            theGame.theGame().buildFloorShop(shop = Shop(shop = boutique, price = theGame.theGame()._level))
        elif j==4:
            theGame.theGame().buildFloorTrap()
        elif j==5:
            theGame.theGame().buildFloorTresor()
            
        theGame.theGame().addMessage("The " + hero.name + " goes down")
        theGame.theGame().floor_level+=1
